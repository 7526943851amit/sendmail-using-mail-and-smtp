<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            text-align: center;
        }
        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #4285f4;
            margin-bottom: 20px;
        }
        p {
            color: #666666;
            margin-bottom: 20px;
        }
        .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #4285f4;
            color: #ffffff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .button:hover {
            background-color: #3a74c5;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to Diet Plan!</h1>
        <p>Dear <?php echo $name,$height; ?>,</p>
        <p>Thank you for registering for the diet plan.!</p>
        <p>Best regards,<br>Diet Plan Team</p>
        <a href="#" class="button">My site url</a>
    </div>
</body>
</html>
