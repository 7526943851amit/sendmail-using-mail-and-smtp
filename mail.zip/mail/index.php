<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

    <form id="contactForm">
        

        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required><br>
        <label for="to">Email:</label>
        <input type="email" id="email" name="email" required><br>

        <button type="button"  id="submitButton">Submit</button>
    </form>

    <div id="responseMessage"></div>
    
    <script>
        $(document).ready(function() {
            $("#submitButton").click(function() {
               
                // alert("chfghfg"); 
                var formData = {
                name: $("#name").val(),
                email: $("#email").val()
            };

                $.ajax({
                    type: "POST",
                    url: "emal_send.php",
                    data: formData,
                    success: function(response) {
                        $("#responseMessage").html(response);
                    }
                });
            });
        });
    </script>

</body>
</html>
