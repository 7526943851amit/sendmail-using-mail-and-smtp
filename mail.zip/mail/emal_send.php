<?php
$servername = "localhost";
$username = "root";
$password = "";
$db="dietplan";

$conn = new mysqli($servername, $username, $password, $db);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $checkEmailQuery = "SELECT * FROM diet_plan_email WHERE Email = '$email'";
    $result = $conn->query($checkEmailQuery);

    if ($result->num_rows > 0) {
        echo "Error: Email already exists.";
    }
    else{
    $sql = "INSERT INTO diet_plan_email (Name, Email)
  VALUES ('$name','$email')";
 
  
  if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
     $to = $_POST["email"];
     $name = $_POST["name"];
     $subject = "Diet Plan ";
     $message = "Dear $name,\n\nThank you for registering for the diet plan.";
     $headers = "From: amitbytecode123@gmail.com";

     $mailSuccess = mail($to, $subject, $message, $headers);

     if ($mailSuccess) {
         echo "Email sent successfully";
     } else {
         echo "Error: Unable to send email.";
     }
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
}
}

?>
